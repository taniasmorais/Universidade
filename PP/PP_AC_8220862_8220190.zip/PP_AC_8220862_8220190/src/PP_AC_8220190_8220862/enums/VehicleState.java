/*
* Nome: Tomás Leonardo Leão Sousa Neto
* Número: 8220862
* Turma: LSIRC12T1
*
* Nome: Tânia Sofia da Silva Morais
* Número: 8220190
* Turma: LSIRC12T1
 */
package PP_AC_8220190_8220862.enums;

/**
 *<strong>  VehicleState </strong>
 *<p> enum of a vehicle state </p>
 * @author tomas
 */
public enum VehicleState {
    ACTIVE, INACTIVE;
}
