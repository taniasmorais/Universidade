package ExceptionsAulas;

public class EmptyCollectionException extends Exception {
    public EmptyCollectionException(String msg) {
        super(msg);
    }
}
