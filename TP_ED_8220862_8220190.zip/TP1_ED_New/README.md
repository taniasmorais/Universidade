# TrabalhoED_Novo

Para o correto funcionamento deste trabalho é necessário ter a biblioteca JSONsimple (json-simple-1.1.1.jar) instalada 
