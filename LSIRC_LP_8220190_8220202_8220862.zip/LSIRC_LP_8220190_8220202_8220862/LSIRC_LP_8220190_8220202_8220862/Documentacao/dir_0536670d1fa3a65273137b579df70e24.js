var dir_0536670d1fa3a65273137b579df70e24 =
[
    [ "branchs.c", "branchs_8c.html", "branchs_8c" ],
    [ "branchs.h", "branchs_8h.html", "branchs_8h" ],
    [ "comments.c", "comments_8c.html", "comments_8c" ],
    [ "comments.h", "comments_8h.html", "comments_8h" ],
    [ "companys.c", "companys_8c.html", "companys_8c" ],
    [ "companys.h", "companys_8h.html", "companys_8h" ],
    [ "input.c", "input_8c.html", "input_8c" ],
    [ "input.h", "input_8h.html", "input_8h" ],
    [ "menus.c", "menus_8c.html", "menus_8c" ],
    [ "menus.h", "menus_8h.html", "menus_8h" ]
];