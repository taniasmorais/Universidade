var searchData=
[
  ['company_5faverage_0',['company_average',['../companys_8c.html#a2ed731239a0107cec6f3e78a967d603f',1,'companys.c']]],
  ['company_5fmanage_5fmenu_1',['company_manage_menu',['../menus_8c.html#a310eb0d8c8871b8ef062d0a2364936f2',1,'company_manage_menu(Companies *companies, ActivityBranchs *branchs, Comments *comments):&#160;menus.c'],['../menus_8h.html#a310eb0d8c8871b8ef062d0a2364936f2',1,'company_manage_menu(Companies *companies, ActivityBranchs *branchs, Comments *comments):&#160;menus.c']]],
  ['company_5fmenu_2',['company_menu',['../menus_8c.html#a70031e496555aafe152de4b81b97de63',1,'company_menu(Companies *companies, Comments *comments, ActivityBranchs *branchs):&#160;menus.c'],['../menus_8h.html#a70031e496555aafe152de4b81b97de63',1,'company_menu(Companies *companies, Comments *comments, ActivityBranchs *branchs):&#160;menus.c']]],
  ['compare_5fcompany_3',['compare_company',['../companys_8c.html#a64ba6556efde2fdd32b97c7d894d34ac',1,'companys.c']]],
  ['compare_5frate_4',['compare_rate',['../companys_8c.html#aec472c5d79d85585fccae1552a606307',1,'companys.c']]],
  ['creatcompanyreport_5',['creatCompanyReport',['../companys_8c.html#a9ff8eeed8fd4240e9d4b72a366ff85dd',1,'creatCompanyReport(Companies *companies, int companyPosition):&#160;companys.c'],['../companys_8h.html#a9ff8eeed8fd4240e9d4b72a366ff85dd',1,'creatCompanyReport(Companies *companies, int companyPosition):&#160;companys.c']]],
  ['createactivitybranch_6',['createActivityBranch',['../branchs_8c.html#a4bed5f2589b738295093faef35848d90',1,'branchs.c']]],
  ['createactivitybranchs_7',['createActivityBranchs',['../branchs_8c.html#aefb7f2e710dbf2297afead839b6665e3',1,'createActivityBranchs(ActivityBranchs *branchs):&#160;branchs.c'],['../branchs_8h.html#aefb7f2e710dbf2297afead839b6665e3',1,'createActivityBranchs(ActivityBranchs *branchs):&#160;branchs.c']]],
  ['createcomment_8',['createComment',['../comments_8c.html#a840bde8fc0ae02bc72013da2db6a33c1',1,'comments.c']]],
  ['createcomments_9',['createComments',['../comments_8c.html#a7867dab43166058fef14f6620812a8ca',1,'createComments(Comments *comments, Companies companies):&#160;comments.c'],['../comments_8h.html#a7867dab43166058fef14f6620812a8ca',1,'createComments(Comments *comments, Companies companies):&#160;comments.c']]],
  ['createcompanies_10',['createCompanies',['../companys_8c.html#a2fb93fd0852c81311657bbf78d557c6c',1,'createCompanies(Companies *companies, ActivityBranchs *branchs):&#160;companys.c'],['../companys_8h.html#a2fb93fd0852c81311657bbf78d557c6c',1,'createCompanies(Companies *companies, ActivityBranchs *branchs):&#160;companys.c']]],
  ['createcompany_11',['createCompany',['../companys_8c.html#a3d5217407bf617c577ed7a2ea31ec8fa',1,'companys.c']]]
];
