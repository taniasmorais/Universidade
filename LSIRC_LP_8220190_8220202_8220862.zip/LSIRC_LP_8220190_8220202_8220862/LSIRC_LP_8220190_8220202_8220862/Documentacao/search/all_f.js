var searchData=
[
  ['updateactivitybranchs_0',['updateActivityBranchs',['../branchs_8h.html#a1114d201a35b33c03f6324b2c3ea3bc5',1,'branchs.h']]],
  ['updatecompanies_1',['updateCompanies',['../companys_8c.html#afcb3aeb4606cc63d67c448835b52bcb0',1,'updateCompanies(Companies *companies, ActivityBranchs *branchs):&#160;companys.c'],['../companys_8h.html#afcb3aeb4606cc63d67c448835b52bcb0',1,'updateCompanies(Companies *companies, ActivityBranchs *branchs):&#160;companys.c']]],
  ['updatecompany_2',['updateCompany',['../companys_8c.html#a1fda4e36e85398362e6cdc4532c2b2f7',1,'updateCompany(Company *company, ActivityBranchs *branchs):&#160;companys.c'],['../companys_8h.html#a1fda4e36e85398362e6cdc4532c2b2f7',1,'updateCompany(Company *company, ActivityBranchs *branchs):&#160;companys.c']]],
  ['user_5fmenu_3',['user_menu',['../menus_8c.html#ae2136b960d54e97bf927de15d057b494',1,'user_menu(Companies *companies, ActivityBranchs *branchs, Comments *comments):&#160;menus.c'],['../menus_8h.html#ae2136b960d54e97bf927de15d057b494',1,'user_menu(Companies *companies, ActivityBranchs *branchs, Comments *comments):&#160;menus.c']]]
];
