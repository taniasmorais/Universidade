var searchData=
[
  ['activitybranch_0',['ActivityBranch',['../struct_activity_branch.html',1,'']]],
  ['activitybranchs_1',['ActivityBranchs',['../struct_activity_branchs.html',1,'']]],
  ['admin_5fmenu_2',['admin_menu',['../menus_8c.html#a9e18afd483e2b0e4355935e3b006ef0a',1,'admin_menu(Companies *companies, ActivityBranchs *branchs, Comments *comments):&#160;menus.c'],['../menus_8h.html#a9e18afd483e2b0e4355935e3b006ef0a',1,'admin_menu(Companies *companies, ActivityBranchs *branchs, Comments *comments):&#160;menus.c']]]
];
