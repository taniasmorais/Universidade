var searchData=
[
  ['valor_5finvalido_0',['VALOR_INVALIDO',['../input_8c.html#a7dac90953bf2709d6153d7503fe3c77e',1,'input.c']]],
  ['verify_5fpostalcode_1',['verify_PostalCode',['../companys_8c.html#aa3ad1f44bdbddd3a68a52ec422c1154c',1,'companys.c']]],
  ['verifyabname_2',['verifyABName',['../branchs_8c.html#a9dc623a8d8a8f4d669a69d05608be85e',1,'branchs.c']]],
  ['verifyemail_3',['verifyEmail',['../comments_8c.html#a237ffa317bcd223ba64413fe669c84f7',1,'comments.c']]],
  ['verifyname_4',['verifyName',['../companys_8c.html#a9b9995b294a82e3f66108344d1fe85e8',1,'companys.c']]],
  ['verifynif_5',['verifyNif',['../companys_8c.html#a83a4298fe8dd2895d50effe6eec8f5c1',1,'companys.c']]]
];
