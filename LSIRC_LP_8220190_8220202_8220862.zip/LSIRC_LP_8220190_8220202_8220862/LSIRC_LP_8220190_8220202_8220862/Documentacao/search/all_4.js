var searchData=
[
  ['expandbranchscapacity_0',['expandBranchsCapacity',['../branchs_8c.html#aab38192b601e8b1bd3aa4dc3ab1ad2de',1,'branchs.c']]],
  ['expandcommentscapacity_1',['expandCommentsCapacity',['../comments_8c.html#aa42e5eba4905eb225121068577cdedf6',1,'comments.c']]],
  ['expandcompaniescapacity_2',['expandCompaniesCapacity',['../companys_8c.html#a78a926a8c8152b3b68d606d85d3c7098',1,'companys.c']]]
];
