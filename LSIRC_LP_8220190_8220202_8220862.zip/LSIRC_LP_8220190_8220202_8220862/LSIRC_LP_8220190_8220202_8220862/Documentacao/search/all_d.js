var searchData=
[
  ['savebranchs_0',['saveBranchs',['../branchs_8c.html#ad64d324c335b9aabb07e9a26b81a444a',1,'saveBranchs(ActivityBranchs *branchs, char *file):&#160;branchs.c'],['../branchs_8h.html#ad64d324c335b9aabb07e9a26b81a444a',1,'saveBranchs(ActivityBranchs *branchs, char *file):&#160;branchs.c']]],
  ['savecomments_1',['saveComments',['../comments_8c.html#a5eaa622e4a801af50dfea03b4006e906',1,'saveComments(Comments *comments, char *file):&#160;comments.c'],['../comments_8h.html#a5eaa622e4a801af50dfea03b4006e906',1,'saveComments(Comments *comments, char *file):&#160;comments.c']]],
  ['savecompanies_2',['saveCompanies',['../companys_8c.html#afdc9bb60710d7ce757e1fff89d96421a',1,'saveCompanies(Companies *companies, char *file):&#160;companys.c'],['../companys_8h.html#afdc9bb60710d7ce757e1fff89d96421a',1,'saveCompanies(Companies *companies, char *file):&#160;companys.c']]],
  ['search_5fcompany_5fmenu_3',['search_company_menu',['../menus_8c.html#a28709d8be20cdf6f4b921fff8bf1f15d',1,'search_company_menu(Companies *companies, ActivityBranchs *branchs):&#160;menus.c'],['../menus_8h.html#a28709d8be20cdf6f4b921fff8bf1f15d',1,'search_company_menu(Companies *companies, ActivityBranchs *branchs):&#160;menus.c']]],
  ['searchactivitybranch_4',['searchActivityBranch',['../branchs_8c.html#a45e747b1c7bf13de6e8f754504e6d9f3',1,'searchActivityBranch(ActivityBranchs branchs, int code):&#160;branchs.c'],['../branchs_8h.html#a45e747b1c7bf13de6e8f754504e6d9f3',1,'searchActivityBranch(ActivityBranchs branchs, int code):&#160;branchs.c']]],
  ['searchcomment_5',['searchComment',['../comments_8c.html#a9ecfaa08dab626db577c0def9bbeb43c',1,'comments.c']]],
  ['searchcompanybycategory_6',['searchCompanyByCategory',['../companys_8c.html#afef18acc2f8331d5b4d7ec571e61f9b8',1,'companys.c']]],
  ['searchcompanybyname_7',['searchCompanyByName',['../companys_8c.html#a3f93c4ee4ec4fef40b45323628ccc5e7',1,'searchCompanyByName(Companies companies, char *name):&#160;companys.c'],['../companys_8h.html#a3f93c4ee4ec4fef40b45323628ccc5e7',1,'searchCompanyByName(Companies companies, char *name):&#160;companys.c']]],
  ['searhabname_8',['searhAbName',['../branchs_8c.html#a4b9ee838acd4ab24bc345fb88738d963',1,'branchs.c']]],
  ['selectcompany_9',['selectCompany',['../companys_8c.html#a53a8999670558e18abaa6e9907f58d89',1,'selectCompany(Companies companies):&#160;companys.c'],['../companys_8h.html#a53a8999670558e18abaa6e9907f58d89',1,'selectCompany(Companies companies):&#160;companys.c']]],
  ['sortrate_10',['sortRate',['../companys_8c.html#af12a3defb2288f137a125f401fe57363',1,'companys.c']]],
  ['sortviews_11',['sortViews',['../companys_8c.html#ace48f47db3ffac22e26c7de7e632e14e',1,'companys.c']]]
];
