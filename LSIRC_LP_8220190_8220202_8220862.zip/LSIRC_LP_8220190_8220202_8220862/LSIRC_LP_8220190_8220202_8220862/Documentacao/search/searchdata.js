var indexSectionsWithContent =
{
  0: "abcdefghilmprstuv",
  1: "ac",
  2: "bcim",
  3: "acdefghilmprstuv",
  4: "v"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Macros"
};

