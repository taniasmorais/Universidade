var searchData=
[
  ['isactive_0',['isActive',['../branchs_8c.html#ad59518bb761b5e7e3f1af064d167dc34',1,'branchs.c']]],
  ['isintop5bestrated_1',['isInTop5BestRated',['../companys_8c.html#a29f2f10868ac9f0d322ff253fa2b66e2',1,'companys.c']]],
  ['isintop5mostviewed_2',['isInTop5MostViewed',['../companys_8c.html#a411db77ba28172a82f419af109b7ae70',1,'companys.c']]],
  ['isstateactive_3',['isStateActive',['../comments_8c.html#a4d3ab0aa87a64a1e3d23e2d595b3df95',1,'comments.c']]]
];
