var searchData=
[
  ['activitybranch_0',['ActivityBranch',['../struct_activity_branch.html',1,'']]],
  ['activitybranchs_1',['ActivityBranchs',['../struct_activity_branchs.html',1,'']]]
];
