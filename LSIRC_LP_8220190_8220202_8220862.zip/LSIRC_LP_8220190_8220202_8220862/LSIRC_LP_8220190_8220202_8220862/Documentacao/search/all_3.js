var searchData=
[
  ['deleteactivitybranch_0',['deleteActivityBranch',['../branchs_8c.html#a2bf2455bbbbe6696fd4b522b2fb164f4',1,'branchs.c']]],
  ['deleteactivitybranchs_1',['deleteActivityBranchs',['../branchs_8c.html#a866e5e6ffafa9fe0aef2bcd023e14ea4',1,'deleteActivityBranchs(ActivityBranchs *branchs, Companies *companies):&#160;branchs.c'],['../branchs_8h.html#aa23c53ad23e8dd8b9388b4a9444b1e48',1,'deleteActivityBranchs():&#160;branchs.h']]],
  ['deletecomment_2',['deleteComment',['../comments_8c.html#af7bfae87ee1364f458fbd739f248c6a3',1,'comments.c']]],
  ['deletecomments_3',['deleteComments',['../comments_8c.html#a5ca7654f4650a7898fc475fa2b8cac61',1,'deleteComments(Comments *comments):&#160;comments.c'],['../comments_8h.html#a5ca7654f4650a7898fc475fa2b8cac61',1,'deleteComments(Comments *comments):&#160;comments.c']]],
  ['deletecompanies_4',['deleteCompanies',['../companys_8c.html#a632f37038445d419869f6a3d989388fe',1,'deleteCompanies(Companies *companies, Comments *comments):&#160;companys.c'],['../companys_8h.html#a7712d8341afbc9f33240b9bb1a4844b2',1,'deleteCompanies():&#160;companys.h']]],
  ['deletecompanydata_5',['deleteCompanyData',['../companys_8c.html#acdb5f1c6761adb18b6d7ddf07c96578b',1,'companys.c']]]
];
