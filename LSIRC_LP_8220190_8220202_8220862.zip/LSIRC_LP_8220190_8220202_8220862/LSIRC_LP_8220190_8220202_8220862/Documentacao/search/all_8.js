var searchData=
[
  ['input_2ec_0',['input.c',['../input_8c.html',1,'']]],
  ['input_2eh_1',['input.h',['../input_8h.html',1,'']]],
  ['isactive_2',['isActive',['../branchs_8c.html#ad59518bb761b5e7e3f1af064d167dc34',1,'branchs.c']]],
  ['isintop5bestrated_3',['isInTop5BestRated',['../companys_8c.html#a29f2f10868ac9f0d322ff253fa2b66e2',1,'companys.c']]],
  ['isintop5mostviewed_4',['isInTop5MostViewed',['../companys_8c.html#a411db77ba28172a82f419af109b7ae70',1,'companys.c']]],
  ['isstateactive_5',['isStateActive',['../comments_8c.html#a4d3ab0aa87a64a1e3d23e2d595b3df95',1,'comments.c']]]
];
