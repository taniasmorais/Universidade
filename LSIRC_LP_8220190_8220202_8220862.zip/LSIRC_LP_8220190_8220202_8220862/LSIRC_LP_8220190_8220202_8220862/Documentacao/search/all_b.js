var searchData=
[
  ['printactivitybranch_0',['printActivityBranch',['../branchs_8c.html#ad1784079a42e64aecb5e4e11f8678d18',1,'printActivityBranch(ActivityBranch branch):&#160;branchs.c'],['../branchs_8h.html#ad1784079a42e64aecb5e4e11f8678d18',1,'printActivityBranch(ActivityBranch branch):&#160;branchs.c']]],
  ['printcomment_1',['printComment',['../comments_8c.html#a7c639e5239993a313f857dd8ed67ac53',1,'comments.c']]],
  ['printcommentadmin_2',['printCommentAdmin',['../comments_8c.html#a0799bdb0f71120368edadcf6c271d2af',1,'comments.c']]],
  ['printcompany_3',['printCompany',['../companys_8c.html#ac934af7535ad88949b6e1f3d29a28301',1,'companys.c']]]
];
