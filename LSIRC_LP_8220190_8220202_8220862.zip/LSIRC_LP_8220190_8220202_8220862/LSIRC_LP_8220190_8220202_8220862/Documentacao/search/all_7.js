var searchData=
[
  ['hascomments_0',['hasComments',['../companys_8c.html#aa9ce115512c93bcf43ae0bc18c86078e',1,'hasComments(Company company, Comments comments):&#160;companys.c'],['../companys_8h.html#a54105f7f9cf575343a0f4184459b8db2',1,'hasComments():&#160;companys.h']]],
  ['hascompany_1',['hasCompany',['../branchs_8c.html#a54a3b685896e5edf7505ecc8c804a151',1,'branchs.c']]],
  ['hidecomment_2',['hideComment',['../comments_8c.html#a31e84c1d658888aa105f6abfa9090d27',1,'hideComment(Company company, Comments *comments):&#160;comments.c'],['../comments_8h.html#a31e84c1d658888aa105f6abfa9090d27',1,'hideComment(Company company, Comments *comments):&#160;comments.c']]],
  ['hidecomments_3',['hideComments',['../comments_8c.html#a0c548d9add4b1b7c018b3342162bcf68',1,'hideComments(Companies *companies, Comments *comments):&#160;comments.c'],['../comments_8h.html#a0c548d9add4b1b7c018b3342162bcf68',1,'hideComments(Companies *companies, Comments *comments):&#160;comments.c']]]
];
