var searchData=
[
  ['verify_5fpostalcode_0',['verify_PostalCode',['../companys_8c.html#aa3ad1f44bdbddd3a68a52ec422c1154c',1,'companys.c']]],
  ['verifyabname_1',['verifyABName',['../branchs_8c.html#a9dc623a8d8a8f4d669a69d05608be85e',1,'branchs.c']]],
  ['verifyemail_2',['verifyEmail',['../comments_8c.html#a237ffa317bcd223ba64413fe669c84f7',1,'comments.c']]],
  ['verifyname_3',['verifyName',['../companys_8c.html#a9b9995b294a82e3f66108344d1fe85e8',1,'companys.c']]],
  ['verifynif_4',['verifyNif',['../companys_8c.html#a83a4298fe8dd2895d50effe6eec8f5c1',1,'companys.c']]]
];
