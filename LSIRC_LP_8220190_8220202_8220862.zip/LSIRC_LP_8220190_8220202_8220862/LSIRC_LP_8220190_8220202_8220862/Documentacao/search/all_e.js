var searchData=
[
  ['top5bestcompanies_0',['top5bestCompanies',['../companys_8c.html#a1ffc4126436892647080c7e0ac63bec4',1,'top5bestCompanies(Companies *companies):&#160;companys.c'],['../companys_8h.html#a1ffc4126436892647080c7e0ac63bec4',1,'top5bestCompanies(Companies *companies):&#160;companys.c']]],
  ['top5lookedcompanies_1',['top5lookedCompanies',['../companys_8c.html#a6b49cf4595e44edfda98c3757bf2baa6',1,'top5lookedCompanies(Companies *companies):&#160;companys.c'],['../companys_8h.html#a6b49cf4595e44edfda98c3757bf2baa6',1,'top5lookedCompanies(Companies *companies):&#160;companys.c']]]
];
