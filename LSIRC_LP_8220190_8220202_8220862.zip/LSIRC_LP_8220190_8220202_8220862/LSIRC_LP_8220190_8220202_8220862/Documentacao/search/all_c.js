var searchData=
[
  ['rate_5fcompany_0',['rate_company',['../companys_8c.html#aa03722dac82dec80902f7d592a65934c',1,'rate_company(Companies *companies):&#160;companys.c'],['../companys_8h.html#aa03722dac82dec80902f7d592a65934c',1,'rate_company(Companies *companies):&#160;companys.c']]],
  ['readstring_1',['readString',['../input_8c.html#aef92db1dd85273a0509f6c347c79d355',1,'readString(char *string, unsigned int tamanho, char *msg):&#160;input.c'],['../input_8h.html#aef92db1dd85273a0509f6c347c79d355',1,'readString(char *string, unsigned int tamanho, char *msg):&#160;input.c']]],
  ['reports_5fmenu_2',['reports_menu',['../menus_8c.html#aeabc72fe4e44fc29c947d9748a66efe7',1,'reports_menu(Companies *companies):&#160;menus.c'],['../menus_8h.html#aeabc72fe4e44fc29c947d9748a66efe7',1,'reports_menu(Companies *companies):&#160;menus.c']]]
];
