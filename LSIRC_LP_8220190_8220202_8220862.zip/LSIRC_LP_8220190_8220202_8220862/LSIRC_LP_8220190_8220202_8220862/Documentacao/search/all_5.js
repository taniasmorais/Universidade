var searchData=
[
  ['freebranchs_0',['freeBranchs',['../branchs_8c.html#a5a26fd46b758949b08ff9167c7e3d92d',1,'freeBranchs(ActivityBranchs *branchs):&#160;branchs.c'],['../branchs_8h.html#a5a26fd46b758949b08ff9167c7e3d92d',1,'freeBranchs(ActivityBranchs *branchs):&#160;branchs.c']]],
  ['freecomments_1',['freeComments',['../comments_8c.html#a6f5007b57e57f923f22daf4aa3f96e67',1,'freeComments(Comments *comments):&#160;comments.c'],['../comments_8h.html#a6f5007b57e57f923f22daf4aa3f96e67',1,'freeComments(Comments *comments):&#160;comments.c']]],
  ['freecompanies_2',['freeCompanies',['../companys_8c.html#a85e913d9aeacbed8f71d1bcfa1255d05',1,'freeCompanies(Companies *companies):&#160;companys.c'],['../companys_8h.html#a85e913d9aeacbed8f71d1bcfa1255d05',1,'freeCompanies(Companies *companies):&#160;companys.c']]]
];
