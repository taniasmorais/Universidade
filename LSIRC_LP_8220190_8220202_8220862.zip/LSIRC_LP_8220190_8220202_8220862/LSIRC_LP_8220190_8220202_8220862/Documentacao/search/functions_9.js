var searchData=
[
  ['main_5fmenu_0',['main_menu',['../menus_8c.html#a885611589f6294afada89fe88362e863',1,'main_menu():&#160;menus.c'],['../menus_8h.html#a885611589f6294afada89fe88362e863',1,'main_menu():&#160;menus.c']]],
  ['manage_5factivity_5fbranch_5fmenu_1',['manage_activity_branch_menu',['../menus_8c.html#a3d1904ac0c9e031c9a607f2ab6148b92',1,'manage_activity_branch_menu(ActivityBranchs *branchs, Companies *companies):&#160;menus.c'],['../menus_8h.html#a3d1904ac0c9e031c9a607f2ab6148b92',1,'manage_activity_branch_menu(ActivityBranchs *branchs, Companies *companies):&#160;menus.c']]]
];
