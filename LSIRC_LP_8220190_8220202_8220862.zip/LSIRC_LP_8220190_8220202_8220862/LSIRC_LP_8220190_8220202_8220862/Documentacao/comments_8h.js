var comments_8h =
[
    [ "Comment", "struct_comment.html", null ],
    [ "Comments", "struct_comments.html", null ],
    [ "createComments", "comments_8h.html#a7867dab43166058fef14f6620812a8ca", null ],
    [ "deleteComments", "comments_8h.html#a5ca7654f4650a7898fc475fa2b8cac61", null ],
    [ "freeComments", "comments_8h.html#a6f5007b57e57f923f22daf4aa3f96e67", null ],
    [ "hideComment", "comments_8h.html#a31e84c1d658888aa105f6abfa9090d27", null ],
    [ "hideComments", "comments_8h.html#a0c548d9add4b1b7c018b3342162bcf68", null ],
    [ "listComments", "comments_8h.html#a4c5abe5c13a2c28b1dc3261c04c50288", null ],
    [ "listCommentsAdmin", "comments_8h.html#adb0271c464a1be447a3266e1b01a0516", null ],
    [ "loadComments", "comments_8h.html#aebad92bf872155f3f1c780c2957e3e45", null ],
    [ "saveComments", "comments_8h.html#a5eaa622e4a801af50dfea03b4006e906", null ]
];