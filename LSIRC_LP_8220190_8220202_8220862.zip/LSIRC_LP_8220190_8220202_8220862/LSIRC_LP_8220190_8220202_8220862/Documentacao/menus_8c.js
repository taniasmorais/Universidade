var menus_8c =
[
    [ "admin_menu", "menus_8c.html#a9e18afd483e2b0e4355935e3b006ef0a", null ],
    [ "company_manage_menu", "menus_8c.html#a310eb0d8c8871b8ef062d0a2364936f2", null ],
    [ "company_menu", "menus_8c.html#a70031e496555aafe152de4b81b97de63", null ],
    [ "main_menu", "menus_8c.html#a885611589f6294afada89fe88362e863", null ],
    [ "manage_activity_branch_menu", "menus_8c.html#a3d1904ac0c9e031c9a607f2ab6148b92", null ],
    [ "reports_menu", "menus_8c.html#aeabc72fe4e44fc29c947d9748a66efe7", null ],
    [ "search_company_menu", "menus_8c.html#a28709d8be20cdf6f4b921fff8bf1f15d", null ],
    [ "user_menu", "menus_8c.html#ae2136b960d54e97bf927de15d057b494", null ]
];