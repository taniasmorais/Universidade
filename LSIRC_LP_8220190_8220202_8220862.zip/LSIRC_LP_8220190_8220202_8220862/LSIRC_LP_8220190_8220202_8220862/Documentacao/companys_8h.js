var companys_8h =
[
    [ "Company", "struct_company.html", null ],
    [ "Companies", "struct_companies.html", null ],
    [ "creatCompanyReport", "companys_8h.html#a9ff8eeed8fd4240e9d4b72a366ff85dd", null ],
    [ "createCompanies", "companys_8h.html#a2fb93fd0852c81311657bbf78d557c6c", null ],
    [ "deleteCompanies", "companys_8h.html#a7712d8341afbc9f33240b9bb1a4844b2", null ],
    [ "freeCompanies", "companys_8h.html#a85e913d9aeacbed8f71d1bcfa1255d05", null ],
    [ "hasComments", "companys_8h.html#a54105f7f9cf575343a0f4184459b8db2", null ],
    [ "listCompanies", "companys_8h.html#a01a13dea79bbf862b0be331095788ca6", null ],
    [ "listCompaniesByCategory", "companys_8h.html#ace8ec0de16cfd15e9e72849e9c7a9a65", null ],
    [ "listCompaniesByLocality", "companys_8h.html#a4647ff7089942b1bbe9ef2b22417f65a", null ],
    [ "listCompaniesByName", "companys_8h.html#a4282cecb1e9fcd9f923beaff319a0959", null ],
    [ "loadCompanies", "companys_8h.html#a7de8b12c2f6735c5f76297a58cdb804b", null ],
    [ "rate_company", "companys_8h.html#aa03722dac82dec80902f7d592a65934c", null ],
    [ "saveCompanies", "companys_8h.html#afdc9bb60710d7ce757e1fff89d96421a", null ],
    [ "searchCompanyByName", "companys_8h.html#a3f93c4ee4ec4fef40b45323628ccc5e7", null ],
    [ "selectCompany", "companys_8h.html#a53a8999670558e18abaa6e9907f58d89", null ],
    [ "top5bestCompanies", "companys_8h.html#a1ffc4126436892647080c7e0ac63bec4", null ],
    [ "top5lookedCompanies", "companys_8h.html#a6b49cf4595e44edfda98c3757bf2baa6", null ],
    [ "updateCompanies", "companys_8h.html#afcb3aeb4606cc63d67c448835b52bcb0", null ],
    [ "updateCompany", "companys_8h.html#a1fda4e36e85398362e6cdc4532c2b2f7", null ]
];