var branchs_8c =
[
    [ "createActivityBranch", "branchs_8c.html#a4bed5f2589b738295093faef35848d90", null ],
    [ "createActivityBranchs", "branchs_8c.html#aefb7f2e710dbf2297afead839b6665e3", null ],
    [ "deleteActivityBranch", "branchs_8c.html#a2bf2455bbbbe6696fd4b522b2fb164f4", null ],
    [ "deleteActivityBranchs", "branchs_8c.html#a866e5e6ffafa9fe0aef2bcd023e14ea4", null ],
    [ "expandBranchsCapacity", "branchs_8c.html#aab38192b601e8b1bd3aa4dc3ab1ad2de", null ],
    [ "freeBranchs", "branchs_8c.html#a5a26fd46b758949b08ff9167c7e3d92d", null ],
    [ "getBranch", "branchs_8c.html#ae2fc4d1a5bcabac9f4725aab1d058d08", null ],
    [ "hasCompany", "branchs_8c.html#a54a3b685896e5edf7505ecc8c804a151", null ],
    [ "isActive", "branchs_8c.html#ad59518bb761b5e7e3f1af064d167dc34", null ],
    [ "listActivityBranchs", "branchs_8c.html#ac83ae0de20aa39fbec553f8d044f7eef", null ],
    [ "loadBranchs", "branchs_8c.html#a7f7d972f7744b78764a700ad987e2b0b", null ],
    [ "printActivityBranch", "branchs_8c.html#ad1784079a42e64aecb5e4e11f8678d18", null ],
    [ "saveBranchs", "branchs_8c.html#ad64d324c335b9aabb07e9a26b81a444a", null ],
    [ "searchActivityBranch", "branchs_8c.html#a45e747b1c7bf13de6e8f754504e6d9f3", null ],
    [ "searhAbName", "branchs_8c.html#a4b9ee838acd4ab24bc345fb88738d963", null ],
    [ "verifyABName", "branchs_8c.html#a9dc623a8d8a8f4d669a69d05608be85e", null ]
];