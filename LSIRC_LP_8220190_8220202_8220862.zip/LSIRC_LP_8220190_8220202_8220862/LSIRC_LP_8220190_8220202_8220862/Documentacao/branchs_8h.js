var branchs_8h =
[
    [ "ActivityBranch", "struct_activity_branch.html", null ],
    [ "ActivityBranchs", "struct_activity_branchs.html", null ],
    [ "createActivityBranchs", "branchs_8h.html#aefb7f2e710dbf2297afead839b6665e3", null ],
    [ "deleteActivityBranchs", "branchs_8h.html#aa23c53ad23e8dd8b9388b4a9444b1e48", null ],
    [ "freeBranchs", "branchs_8h.html#a5a26fd46b758949b08ff9167c7e3d92d", null ],
    [ "getBranch", "branchs_8h.html#ae2fc4d1a5bcabac9f4725aab1d058d08", null ],
    [ "listActivityBranchs", "branchs_8h.html#ac83ae0de20aa39fbec553f8d044f7eef", null ],
    [ "loadBranchs", "branchs_8h.html#a7f7d972f7744b78764a700ad987e2b0b", null ],
    [ "printActivityBranch", "branchs_8h.html#ad1784079a42e64aecb5e4e11f8678d18", null ],
    [ "saveBranchs", "branchs_8h.html#ad64d324c335b9aabb07e9a26b81a444a", null ],
    [ "searchActivityBranch", "branchs_8h.html#a45e747b1c7bf13de6e8f754504e6d9f3", null ],
    [ "updateActivityBranchs", "branchs_8h.html#a1114d201a35b33c03f6324b2c3ea3bc5", null ]
];