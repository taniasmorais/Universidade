var input_8h =
[
    [ "getChar", "input_8h.html#a961baca27fa1c227e7e55378bb3f0820", null ],
    [ "getDouble", "input_8h.html#a2b5f6dbb7e2fd5b1c6cb94a1ea1ba37b", null ],
    [ "getFloat", "input_8h.html#a996141d1e3a2c963af8455c8914ebc8f", null ],
    [ "getInt", "input_8h.html#a5d1a58026269658df4e43e77a270e0e4", null ],
    [ "readString", "input_8h.html#aef92db1dd85273a0509f6c347c79d355", null ]
];