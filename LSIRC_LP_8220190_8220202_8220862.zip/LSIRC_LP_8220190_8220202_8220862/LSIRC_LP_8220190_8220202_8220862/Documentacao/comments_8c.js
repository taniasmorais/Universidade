var comments_8c =
[
    [ "createComment", "comments_8c.html#a840bde8fc0ae02bc72013da2db6a33c1", null ],
    [ "createComments", "comments_8c.html#a7867dab43166058fef14f6620812a8ca", null ],
    [ "deleteComment", "comments_8c.html#af7bfae87ee1364f458fbd739f248c6a3", null ],
    [ "deleteComments", "comments_8c.html#a5ca7654f4650a7898fc475fa2b8cac61", null ],
    [ "expandCommentsCapacity", "comments_8c.html#aa42e5eba4905eb225121068577cdedf6", null ],
    [ "freeComments", "comments_8c.html#a6f5007b57e57f923f22daf4aa3f96e67", null ],
    [ "hideComment", "comments_8c.html#a31e84c1d658888aa105f6abfa9090d27", null ],
    [ "hideComments", "comments_8c.html#a0c548d9add4b1b7c018b3342162bcf68", null ],
    [ "isStateActive", "comments_8c.html#a4d3ab0aa87a64a1e3d23e2d595b3df95", null ],
    [ "listComments", "comments_8c.html#a4c5abe5c13a2c28b1dc3261c04c50288", null ],
    [ "listCommentsAdmin", "comments_8c.html#adb0271c464a1be447a3266e1b01a0516", null ],
    [ "loadComments", "comments_8c.html#aebad92bf872155f3f1c780c2957e3e45", null ],
    [ "printComment", "comments_8c.html#a7c639e5239993a313f857dd8ed67ac53", null ],
    [ "printCommentAdmin", "comments_8c.html#a0799bdb0f71120368edadcf6c271d2af", null ],
    [ "saveComments", "comments_8c.html#a5eaa622e4a801af50dfea03b4006e906", null ],
    [ "searchComment", "comments_8c.html#a9ecfaa08dab626db577c0def9bbeb43c", null ],
    [ "verifyEmail", "comments_8c.html#a237ffa317bcd223ba64413fe669c84f7", null ]
];