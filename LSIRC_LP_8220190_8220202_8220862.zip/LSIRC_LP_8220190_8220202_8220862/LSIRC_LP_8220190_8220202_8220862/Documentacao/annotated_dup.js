var annotated_dup =
[
    [ "ActivityBranch", "struct_activity_branch.html", null ],
    [ "ActivityBranchs", "struct_activity_branchs.html", null ],
    [ "Comment", "struct_comment.html", null ],
    [ "Comments", "struct_comments.html", null ],
    [ "Companies", "struct_companies.html", null ],
    [ "Company", "struct_company.html", null ]
];